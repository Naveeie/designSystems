{{/*
Concatenates the tenant id and kafka topic name.
Usage:
{{ include "uniphore.kafka.topic" (dict "topicName" .Values.kafka.conftopic "context" $) }}
*/}}
{{- define "uniphore.kafka.topic"}}
  {{- if .context.Values.tenant.id}}
    {{- printf "%s.%s" .context.Values.tenant.id .topicName -}}
  {{- else}}
    {{- printf "%s" .topicName -}}
  {{- end }}
{{- end }}
