{{- define "base.resource.annotations" }}
uniphore/helm-chart-name: {{ $.Chart.Name | quote }}
uniphore/helm-release: {{ $.Release.Name | quote }}
uniphore/team: {{ required (printf "'%s.uniphoreTeam' is required" $.path) $.ctx.uniphoreTeam | quote }}
{{- if $.ctx.additionalAnnotations }}
{{- range $key, $val := $.ctx.additionalAnnotations }}
{{ $key }}: {{ tpl $val $ | quote }}
{{- end }}
{{- end }}
{{- end }}

{{- define "base.consumername" -}}
{{- if $.ctx.ingress.kong.keyAuth.consumer.name -}}
{{ printf " %s" $.ctx.ingress.kong.keyAuth.consumer.name }}
{{- else }}
{{ $.ctx.name }}
{{- end -}}
{{- end -}}

{{- define "base.pvcname" -}}
{{- if $.ctx.nfs.pvcName -}}
{{ $.ctx.nfs.pvcName }}
{{- else -}}
{{ printf "%s-nfs-claim" (include "base.name" $ ) }}
{{- end -}}
{{- end -}}

{{- define "base.pvname" -}}
{{- if $.ctx.nfs.pvName -}}
{{ printf "%s-%s" $.ctx.nfs.pvName $.Release.Namespace }}
{{- else -}}
{{ printf "%s-nfs-%s" (include "base.name" $ ) $.Release.Namespace }}
{{- end -}}
{{- end -}}

{{- define "base.consumerusername" -}}
{{- if $.ctx.ingress.kong.keyAuth.consumer.namespaceUser -}}
{{ printf " %s-%s" $.ctx.ingress.kong.keyAuth.consumer.namespaceUser $.Release.Namespace }}
{{- else -}}
{{ printf " %s" $.ctx.ingress.kong.keyAuth.consumer.user }}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "base.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "base.resource.labels" }}
app.kubernetes.io/instance: {{ required (printf "'%s.name' is required" $.path) $.ctx.name | quote }}
app.kubernetes.io/name: {{ required (printf "'%s.name' is required" $.path) $.ctx.name | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- range $key, $val := $.ctx.custom_labels }}
{{ $key }}: {{ tpl $val $ }}
{{- end }}
{{- end }}

{{- define "base.resource.productlabels" }}
{{- $usedBy := default $.ctx.uniphoreTeam $.ctx.usedBy }}
{{- if kindIs "string" $usedBy }}
  {{- range $item := split "," $usedBy }}
app.kubernetes.io/used-by-{{ trim $item }}: "true"
  {{- end }}
{{- else if kindIs "slice" $usedBy }}
  {{- range $item := $usedBy }}
app.kubernetes.io/used-by-{{ $item }}: "true"
  {{- end }}
{{- end }}
{{- end }}



{{- define "base.resource.additional.labels" }}
app.kubernetes.io/version: {{ printf "%s" (regexSplit ":" $.imageId -1 | last) | quote }}
helm.sh/chart: {{ include "base.chart" . }}
{{- $usedBy := default $.ctx.uniphoreTeam $.ctx.usedBy }}
{{- $firstUsedBy := "" }}
{{- if kindIs "string" $usedBy }}
  {{- $firstUsedBy = split "," $usedBy }}
app.kubernetes.io/part-of: {{ $firstUsedBy._0 | quote }}
{{- else if kindIs "slice" $usedBy }}
  {{- $firstUsedBy = index $usedBy 0 }}
app.kubernetes.io/part-of: {{ $firstUsedBy | quote }}
{{- end }}
{{- end }}

{{/*
Labels to use on deploy.spec.selector.matchLabels and svc.spec.selector
*/}}
{{- define "base.resource.matchLabels" -}}
app: {{ required (printf "'%s.name' is required" $.path) $.ctx.name | quote }}
type: {{ required (printf "'%s.type' is required" $.path) $.ctx.type | quote }}
chart: {{ $.Chart.Name | quote }}
release: {{ $.Release.Name | quote }}
{{- end -}}


{{- define "base.resource.service-account.labels" }}
app: {{ required (printf "'%s.name' is required" $.path) $.ctx.name | quote }}
chart: {{ $.Chart.Name | quote }}
release: {{ $.Release.Name | quote }}
{{- range $key, $val := $.ctx.custom_labels }}
{{ $key }}: {{ tpl $val $ }}
{{- end }}
{{- end }}


{{- define "base.name" -}}
{{- $ctx_name := required (printf "'%s.name' is required" $.path) $.ctx.name -}}
{{ printf "%s" $ctx_name }}
{{- end -}}

{{- define "base.namespace" -}}
    {{- if $.Values.namespaceOverride }}
        {{- $.Values.namespaceOverride -}}
    {{- else }}
        {{- .Release.Namespace -}}
    {{- end }}
{{- end -}}


{{/*
Create the name of the service account to use
*/}}
{{- define "base.service_account.name" -}}
{{- if $.ctx.serviceAccount.create -}}
    {{ default (printf "%s-sa" (include "base.name" $)) $.ctx.serviceAccount.name }}
{{- else -}}
    {{ default "default" $.ctx.serviceAccount.name }}
{{- end -}}
{{- end -}}


{{- define "base.dd_service.name" -}}
{{- $ctx_name := required (printf "'%s.name' is required" $.path) $.ctx.name }}
{{- $ctx_type := required (printf "'%s.type' is required" $.path) $.ctx.type -}}
{{- $use_long_name := required (printf "'%s.datadog.use_long_name' is required" $.path) $.ctx.datadog.use_long_name | quote | toString -}}
{{- if or (eq $use_long_name "\"false\"") (eq $use_long_name "false") -}}
{{ printf "%s" $ctx_name }}
{{- else -}}
{{ printf "%s-%s" $ctx_name $ctx_type }}
{{- end -}}
{{- end -}}


{{- define "affinity.matches" }}
{{- $ctx_name := required (printf "'%s.name' is required" $.path) $.ctx.name }}
{{- $ctx_type := required (printf "'%s.type' is required" $.path) $.ctx.type }}
- key: app
  operator: In
  values:
  - {{ $ctx_name | quote }}
- key: type
  operator: In
  values:
  - {{ $ctx_name | quote }}
- key: chart
  operator: In
  values:
  - {{ $.Chart.Name | quote }}
- key: release
  operator: In
  values:
  - {{ $.Release.Name | quote }}
{{- end }}


{{- define "base.datadog.labels" }}
tags.datadoghq.com/env: {{ $.Values.environment | quote }}
tags.datadoghq.com/service: {{ include "base.dd_service.name" $  | quote }}
tags.datadoghq.com/team: {{ $.ctx.uniphoreTeam | quote }}
tags.datadoghq.com/version: {{ printf "%s" (regexSplit ":" $.imageId -1 | last) | quote }}
{{- if contains "uselfserve" .Release.Namespace }}
tags.datadoghq.com/customer: {{ regexReplaceAll "(.*-)(.*)(-uselfserve)" .Release.Namespace "$2" }}
{{- end }}
{{- end }}


{{- define "base.ingress.annotations" }}
{{- if ne $.ctx.ingress.domainName "localhost" -}}
ingress.kubernetes.io/force-ssl-redirect: "true"
{{- end }}
kubernetes.io/ingress.class: {{ default "kong" $.ctx.ingress.class }}
{{- end }}

{{- define "base.ingress.tls" -}}
{{- if ne $.ctx.ingress.domainName "localhost" -}}
tls:
  - hosts:
    {{- range $key,$value := $.ctx.ingress.hosts }}
      - {{ .hostName }}.{{ $.ctx.ingress.domainName }}
    {{- end }}
    secretName: {{ $.ctx.ingress.certName }}
{{- end }}
{{- end }}


{{/*
Renders a value that contains template.
Usage:
{{ include "common.tplvalues.render" ( dict "value" .Values.path.to.the.Value "context" $) }}
*/}}
{{- define "base.tplvalues.render" -}}
    {{- if typeIs "string" .value }}
        {{- tpl .value .context }}
    {{- else }}
        {{- tpl (.value | toYaml) .context }}
    {{- end }}
{{- end -}}

{{- define "base.workloadannotations" -}}
{{- if $.ctx.workloadAnnotations -}}
{{- range $annotation, $val := $.ctx.workloadAnnotations }}
{{ $annotation }}: {{ $val | quote }}
{{- end -}}
{{- end -}}
{{- end -}}
