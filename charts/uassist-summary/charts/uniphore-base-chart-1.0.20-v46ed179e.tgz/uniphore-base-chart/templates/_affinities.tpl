{{/*
Return a soft nodeAffinity definition 
{{ include "base.affinities.nodes.soft" (dict "key" "FOO" "values" (list "BAR" "BAZ")) -}}
*/}}
{{- define "base.affinities.nodes.soft" -}}
preferredDuringSchedulingIgnoredDuringExecution:
  - preference:
      matchExpressions:
        - key: {{ .key }}
          operator: In
          values:
            {{- range .values }}
            - {{ . | quote }}
            {{- end }}
    weight: 1
{{- end -}}

{{/*
Return a hard nodeAffinity definition
{{ include "base.affinities.nodes.hard" (dict "key" "FOO" "values" (list "BAR" "BAZ")) -}}
*/}}
{{- define "base.affinities.nodes.hard" -}}
requiredDuringSchedulingIgnoredDuringExecution:
  nodeSelectorTerms:
    - matchExpressions:
        - key: {{ .key }}
          operator: In
          values:
            {{- range .values }}
            - {{ . | quote }}
            {{- end }}
{{- end -}}

{{/*
Return a nodeAffinity definition
{{ include "base.affinities.nodes" (dict "type" "soft" "key" "FOO" "values" (list "BAR" "BAZ")) -}}
*/}}
{{- define "base.affinities.nodes" -}}
  {{- if eq .type "soft" }}
    {{- include "base.affinities.nodes.soft" . -}}
  {{- else if eq .type "hard" }}
    {{- include "base.affinities.nodes.hard" . -}}
  {{- end -}}
{{- end -}}

{{/*
Return a soft podAffinity/podAntiAffinity definition
{{ include "base.affinities.pods.soft" (dict "component" "FOO" "extraMatchLabels" .Values.extraMatchLabels "context" $) -}}
*/}}
{{- define "base.affinities.pods.soft" -}}
{{- $component := default "" .component -}}
{{- $extraMatchLabels := default (dict) .extraMatchLabels -}}
preferredDuringSchedulingIgnoredDuringExecution:
{{- $topologies := list "topology.kubernetes.io/zone" "kubernetes.io/hostname" }}
{{- range $topology := $topologies }}
  - podAffinityTerm:
      labelSelector:
        matchLabels: {{- (include "base.resource.matchLabels" $.context) | nindent 10 }}
          {{- if not (empty $component) }}
          {{ printf "app.kubernetes.io/component: %s" $component }}
          {{- end }}
          {{- range $key, $value := $extraMatchLabels }}
          {{ $key }}: {{ $value | quote }}
          {{- end }}
      namespaces:
        - {{ $.context.Release.Namespace | quote }}
      topologyKey: {{ $topology | quote }}
    weight: 1
{{- end }}
{{- end -}}

{{/*
Return a hard podAffinity/podAntiAffinity definition
{{ include "base.affinities.pods.hard" (dict "component" "FOO" "extraMatchLabels" .Values.extraMatchLabels "context" $) -}}
*/}}
{{- define "base.affinities.pods.hard" -}}
{{- $component := default "" .component -}}
{{- $extraMatchLabels := default (dict) .extraMatchLabels -}}
requiredDuringSchedulingIgnoredDuringExecution:
{{- $topologies := list "topology.kubernetes.io/zone" "kubernetes.io/hostname" }}
{{- range $topology := $topologies }}
  - labelSelector:
      matchLabels: {{- (include "base.labels.matchLabels" $.context) | nindent 8 }}
        {{- if not (empty $component) }}
        {{ printf "app.kubernetes.io/component: %s" $component }}
        {{- end }}
        {{- range $key, $value := $extraMatchLabels }}
        {{ $key }}: {{ $value | quote }}
        {{- end }}
    namespaces:
      - {{ $.context.Release.Namespace | quote }}
    topologyKey: kubernetes.io/hostname
{{- end }}
{{- end -}}

{{/*
Return a podAffinity/podAntiAffinity definition
{{ include "base.affinities.pods" (dict "type" "soft" "key" "FOO" "values" (list "BAR" "BAZ")) -}}
*/}}
{{- define "base.affinities.pods" -}}
  {{- if eq .type "soft" }}
    {{- include "base.affinities.pods.soft" . -}}
  {{- else if eq .type "hard" }}
    {{- include "base.affinities.pods.hard" . -}}
  {{- end -}}
{{- end -}}
